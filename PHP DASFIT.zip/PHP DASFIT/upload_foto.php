<?php
// upload_foto.php — DasFit (calco Unigo adaptado a correo)
header('Content-Type: application/json');
require 'db_config.php';  // define $conn

// 1) Sólo POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success'=>false,'message'=>'Método no permitido. Usa POST.']);
    exit;
}

// 2) Recoger parámetros
$correo    = $_POST['correo']  ?? '';
$fotoBase64= $_POST['foto']    ?? '';

if (empty($correo) || empty($fotoBase64)) {
    echo json_encode(['success'=>false,'message'=>'Faltan correo o foto.']);
    exit;
}

// 3) Decodificar base64 (soporta data URI)
$extension = 'jpg';
if (preg_match('/^data:image\/(\w+);base64,/', $fotoBase64, $m)) {
    $extension   = strtolower($m[1]);
    $fotoBase64  = substr($fotoBase64, strpos($fotoBase64, ',')+1);
    if (!in_array($extension, ['jpg','jpeg','png','gif'])) {
        echo json_encode(['success'=>false,'message'=>'Tipo no soportado.']);
        exit;
    }
}
$fotoBase64 = str_replace(' ', '+', $fotoBase64);
$data       = base64_decode($fotoBase64);
if ($data === false) {
    echo json_encode(['success'=>false,'message'=>'Imagen inválida.']);
    exit;
}

// 4) Guardar fichero
$dir = __DIR__ . '/fotos_perfil/';
if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
    echo json_encode(['success'=>false,'message'=>'No se pudo crear carpeta.']);
    exit;
}

$cleanCorreo = preg_replace('/[^a-zA-Z0-9]/','', $correo);
$filename    = "profile_{$cleanCorreo}_" . time() . ".{$extension}";
$filePath    = $dir . $filename;

// Solo UNA llamada a file_put_contents, con @ para no generar warning en pantalla
$result = @file_put_contents($filePath, $data);
if ($result === false) {
    // Extraemos el último error de PHP
    $err = error_get_last();
    echo json_encode([
        'success' => false,
        'message' => 'Error al guardar imagen.',
        'debug'   => $err  // esto te dirá “Permission denied” o “No such file…”
    ]);
    exit;
}

// 5) URL pública y actualizar BD
$baseUrl  = 'http://ec2-51-44-167-78.eu-west-3.compute.amazonaws.com/mmartin239/WEB/usuarios';
$imageUrl = "{$baseUrl}/fotos_perfil/{$filename}";

$stmt = $conn->prepare(
    "UPDATE Xmmartin239_usuarios SET foto = ? WHERE correo = ?"
);
$stmt->bind_param("ss", $imageUrl, $correo);
$ok = $stmt->execute();
$stmt->close();
$conn->close();

if ($ok) {
    echo json_encode([
        'success' => true,
        'message' => 'Imagen subida correctamente.',
        'url'     => $imageUrl
    ]);
} else {
    echo json_encode(['success'=>false,'message'=>'Error al actualizar la BD.']);
}
