<?php
// db_config.php — conexión MySQL para DasFit (copia exacta de Unigo adaptada)

define('DB_HOST', 'localhost');
define('DB_USER', 'Xmmartin239');
define('DB_PASS', '9SGD0iby');
define('DB_NAME', 'Xmmartin239_usuarios');

// Crear conexión
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Comprobar conexión
if ($conn->connect_error) {
    
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Error de conexión a la base de datos: ' . $conn->connect_error
    ]);
    exit;
}