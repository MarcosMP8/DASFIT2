<?php
// login.php (versión actualizada)
$DB_SERVER   = "localhost";
$DB_USER     = "Xmmartin239";
$DB_PASS     = "9SGD0iby";
$DB_DATABASE = "Xmmartin239_usuarios";

$con = mysqli_connect($DB_SERVER, $DB_USER, $DB_PASS, $DB_DATABASE);
if (!$con) {
    // si falla la conexión, devolvemos un JSON mínimo (opcional)
    echo "ERROR|No se pudo conectar a la base de datos|";
    exit;
}

$correo     = $_POST['correo']    ?? '';
$contrasena = $_POST['contrasena'] ?? '';

if (empty($correo) || empty($contrasena)) {
    echo "ERROR|Faltan parámetros|";
    mysqli_close($con);
    exit;
}

// 1) Seleccionamos nombre, contrasena y foto (URL) del usuario
$stmt = mysqli_prepare(
    $con,
    "SELECT nombre, contrasena, foto 
     FROM Xmmartin239_usuarios 
     WHERE correo = ?"
);
mysqli_stmt_bind_param($stmt, "s", $correo);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $nombreBD, $hashBD, $fotoUrlBD);

if (mysqli_stmt_fetch($stmt)) {
    // Si encontramos usuario...
    if (password_verify($contrasena, $hashBD)) {
        // 2) Si la contraseña coincide, enviamos “OK|nombre|foto”
        // Si foto está a NULL, forzamos cadena vacía para no romper el split del cliente
        if (empty($fotoUrlBD)) {
            $fotoUrlBD = "";
        }
        echo "OK|" . $nombreBD . "|" . $fotoUrlBD;
    } else {
        // Contraseña incorrecta
        echo "ERROR_CONTRASEÑA_INCORRECTA||";
    }
} else {
    // No existe ese correo
    echo "ERROR_NO_ENCONTRADO||";
}

mysqli_stmt_close($stmt);
mysqli_close($con);
?>