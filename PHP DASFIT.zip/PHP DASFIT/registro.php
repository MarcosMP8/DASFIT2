<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$DB_SERVER = "localhost";
$DB_USER = "Xmmartin239";
$DB_PASS = "9SGD0iby";
$DB_DATABASE = "Xmmartin239_usuarios";

// Conexión
$con = mysqli_connect($DB_SERVER, $DB_USER, $DB_PASS, $DB_DATABASE);

// Verificar conexión
if (!$con) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Recibir datos POST
$nombre = $_POST['nombre'] ?? '';
$correo = $_POST['correo'] ?? '';
$contrasena = $_POST['contrasena'] ?? '';

// Validar que los campos no estén vacíos
if (empty($nombre) || empty($correo) || empty($contrasena)) {
    die("Faltan campos obligatorios.");
}

// Encriptar contraseña
$contrasenaHash = password_hash($contrasena, PASSWORD_DEFAULT);

// Crear la consulta SQL
$query = "INSERT INTO Xmmartin239_usuarios (nombre, correo, contrasena) VALUES (?, ?, ?)";

// Preparar y ejecutar
$stmt = mysqli_prepare($con, $query);
if (!$stmt) {
    die("Error en prepare: " . mysqli_error($con));
}

mysqli_stmt_bind_param($stmt, "sss", $nombre, $correo, $contrasenaHash);

if (mysqli_stmt_execute($stmt)) {
    echo "OK";
} else {
    echo "ERROR: " . mysqli_stmt_error($stmt);
}

mysqli_stmt_close($stmt);
mysqli_close($con);
?>