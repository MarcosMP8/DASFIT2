<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// DEBUG: Mostrar todo lo recibido
//file_put_contents("debug.txt", json_encode($_POST) . "\n", FILE_APPEND);

$DB_SERVER = "localhost";
$DB_USER = "Xmmartin239";
$DB_PASS = "9SGD0iby";
$DB_DATABASE = "Xmmartin239_usuarios";

$con = mysqli_connect($DB_SERVER, $DB_USER, $DB_PASS, $DB_DATABASE);

if (!$con) {
    echo "ERROR_CONEXION";
    exit();
}

$correo_actual = $_POST['correo_actual'] ?? '';
$nombre_nuevo = $_POST['nombre_nuevo'] ?? '';
$correo_nuevo = $_POST['correo_nuevo'] ?? '';

if (empty($correo_actual) || empty($nombre_nuevo) || empty($correo_nuevo)) {
    echo "ERROR_DATOS";
    exit();
}

$query = "UPDATE Xmmartin239_usuarios SET nombre = '$nombre_nuevo', correo = '$correo_nuevo' WHERE correo = '$correo_actual'";
$result = mysqli_query($con, $query);

if ($result) {
    echo "OK";
} else {
    echo "ERROR_QUERY: " . mysqli_error($con);
}

mysqli_close($con);
?>